#include <avr/pgmspace.h>

// Characters as 3 byte numbers where each 4 bits = a row
PROGMEM prog_uint32_t chars[37] =
{ 
  0x699996, // 0
  0x4C444E, // 1
  0x69248F, // 2
  0xF1F11F, // 3
  0x99F111, // 4
  0xF8E11E, // 5   
  0xF8F99F, // 6
  0xF12444, // 7
  0x696996, // 8
  0xF9F11F, // 9

  0x699F99, // A
  0xE9E99E, // B
  0xF8888F, // C
  0xE9999E, // D
  0xF8F88F, // E
  0xF8F888, // F
  0xF8899F, // G
  0x99F999, // H
  0xF6666F, // I
  0x11119F, // J
  0x9ACCA9, // K
  0x88888F, // L
  0x9F9999, // M
  0x9DDBB9, // N
  0xF9999F, // 0
  0xE9E888, // P
  0xF999E1, // Q
  0xE9EB99, // R
  0xF8F11F, // S
  0xF44444, // T
  0x99999F, // U
  0x999966, // V
  0x9999F9, // W
  0x996699, // X
  0x995248, // Y
  0xF1248F, // Z
  0x000000, // Blank
};

